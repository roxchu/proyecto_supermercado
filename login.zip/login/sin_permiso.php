<!DOCTYPE html>
<html lang="es">
<head><title>Acceso Denegado</title></head>
<body>
    <h1>🚫 Acceso Denegado (403)</h1>
    <p>No tienes los permisos necesarios para ver esta página.</p>
    <a href="index.html">Volver al Inicio</a>
</body>
</html>