<?php
/**
 * API para obtener todos los productos disponibles
 * Adaptado para la estructura de BD existente
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

try {
    // Consultar todos los productos con stock disponible incluyendo categoría
    $stmt = $pdo->prepare("
        SELECT 
            p.Id_Producto,
            p.Nombre_Producto,
            p.Descripcion,
            p.precio_actual,
            p.precio_anterior,
            p.Stock,
            p.imagen_url,
            p.es_destacado,
            p.etiqueta_especial,
            p.descuento_texto,
            c.Nombre_Categoria
        FROM producto p
        INNER JOIN categoria c ON p.Id_Categoria = c.Id_Categoria
        WHERE p.Stock > 0 
        ORDER BY c.Nombre_Categoria, p.Nombre_Producto
    ");
    
    $stmt->execute();
    $productos = $stmt->fetchAll();
    
    enviarRespuesta(true, 'Productos obtenidos correctamente', $productos);
    
} catch(PDOException $e) {
    enviarRespuesta(false, 'Error al obtener productos: ' . $e->getMessage());
}
?>