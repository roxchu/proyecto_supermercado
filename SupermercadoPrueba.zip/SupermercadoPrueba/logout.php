<?php
/**
 * API para cerrar sesión de usuario
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

iniciarSesion();

// Destruir todas las variables de sesión
$_SESSION = array();

// Destruir la sesión
session_destroy();

enviarRespuesta(true, 'Sesión cerrada correctamente');
?>