<?php
/**
 * API para autenticación de usuarios
 * Adaptado para la estructura de BD existente
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    enviarRespuesta(false, 'Método no permitido');
}

try {
    iniciarSesion();
    
    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    
    // Validaciones básicas
    if (empty($email) || empty($password)) {
        enviarRespuesta(false, 'Email y contraseña son obligatorios');
    }
    
    // Buscar usuario por email
    $stmt = $pdo->prepare("
        SELECT u.id_usuario, u.DNI, u.nombre_usuario, u.correo, u.contrasena, r.nombre_rol 
        FROM usuario u
        INNER JOIN rol r ON u.id_rol = r.id_rol
        WHERE u.correo = ?
    ");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();
    
    if (!$usuario) {
        enviarRespuesta(false, 'Credenciales incorrectas');
    }
    
    // Verificar contraseña (solo si está hasheada)
    if (!empty($usuario['contrasena']) && !password_verify($password, $usuario['contrasena'])) {
        enviarRespuesta(false, 'Credenciales incorrectas');
    }
    
    // Iniciar sesión
    $_SESSION['id_usuario'] = $usuario['id_usuario'];
    $_SESSION['dni_usuario'] = $usuario['DNI'];
    $_SESSION['nombre_usuario'] = $usuario['nombre_usuario'];
    $_SESSION['email_usuario'] = $usuario['correo'];
    $_SESSION['rol_usuario'] = $usuario['nombre_rol'];
    
    enviarRespuesta(true, 'Login exitoso', [
        'id_usuario' => $usuario['id_usuario'],
        'dni' => $usuario['DNI'],
        'nombre' => $usuario['nombre_usuario'],
        'email' => $usuario['correo'],
        'rol' => $usuario['nombre_rol']
    ]);
    
} catch(PDOException $e) {
    enviarRespuesta(false, 'Error en el login: ' . $e->getMessage());
}
?>