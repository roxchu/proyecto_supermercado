<?php
/**
 * API para verificar el estado de la sesión del usuario
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

try {
    iniciarSesion();
    
    if (usuarioLogueado()) {
        // Usuario logueado, devolver información
        enviarRespuesta(true, 'Usuario logueado', [
            'id_usuario' => $_SESSION['id_usuario'],
            'dni' => $_SESSION['dni_usuario'],
            'nombre' => $_SESSION['nombre_usuario'],
            'email' => $_SESSION['email_usuario'],
            'rol' => $_SESSION['rol_usuario'] ?? 'client'
        ]);
    } else {
        // Usuario no logueado
        enviarRespuesta(false, 'Usuario no logueado');
    }
    
} catch(Exception $e) {
    enviarRespuesta(false, 'Error al verificar sesión: ' . $e->getMessage());
}
?>