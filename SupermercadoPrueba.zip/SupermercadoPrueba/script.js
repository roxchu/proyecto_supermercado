// =====================================================
//  🛒 script.js — versión corregida completa
// =====================================================

// 🔧 Recuperar usuario si se perdió entre páginas
if (!localStorage.getItem('usuario') && sessionStorage.getItem('usuario')) {
    localStorage.setItem('usuario', sessionStorage.getItem('usuario'));
}

// Variables globales
let productos = [];
let productosFiltrados = [];
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
let usuarioLogueado = JSON.parse(localStorage.getItem('usuario')) || null;

// Inicialización al cargar DOM
document.addEventListener('DOMContentLoaded', function() {
    console.log('Usuario logueado detectado:', usuarioLogueado);
    verificarSesion();

    if (window.location.pathname.includes('index.html') || window.location.pathname.endsWith('/') || window.location.pathname === '/') {
        cargarProductos();
    }

    if (window.location.pathname.includes('carrito.html')) {
        cargarCarrito();
    }

    actualizarContadorCarrito();
});

// =====================================================
// 🔐 SESIÓN DE USUARIO
// =====================================================

function verificarSesion() {
    const userInfo = document.getElementById('userInfo');
    const authButtons = document.getElementById('authButtons');
    const userName = document.getElementById('userName');

    if (usuarioLogueado) {
        if (userInfo) userInfo.style.display = 'flex';
        if (authButtons) authButtons.style.display = 'none';
        if (userName) userName.textContent = usuarioLogueado.nombre;
    } else {
        if (userInfo) userInfo.style.display = 'none';
        if (authButtons) authButtons.style.display = 'flex';
    }
}

function logout() {
    localStorage.removeItem('usuario');
    sessionStorage.removeItem('usuario');
    localStorage.removeItem('carrito');
    usuarioLogueado = null;
    carrito = [];
    window.location.reload();
}

// =====================================================
// 📦 CARGA DE PRODUCTOS
// =====================================================

async function cargarProductos() {
    const loading = document.getElementById('loading');
    const productsGrid = document.getElementById('productsGrid');

    try {
        console.log('Intentando cargar productos desde productos.php...');
        const response = await fetch('productos.php', {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
            credentials: 'same-origin'
        });

        if (!response.ok) throw new Error(`HTTP error: ${response.status}`);

        const result = await response.json();
        console.log('Respuesta del servidor:', result);

        if (result.success) {
            productos = result.data;
            productosFiltrados = productos;
            mostrarProductos(productosFiltrados);
            actualizarContadorCarrito();
            if (loading) loading.style.display = 'none';
            return;
        } else {
            throw new Error(result.message || 'Error al cargar productos');
        }
    } catch (error) {
        console.error('Error cargando desde PHP:', error);
        try {
            const response = await fetch('productos_demo.json');
            productos = await response.json();
            productosFiltrados = productos;
            mostrarProductos(productosFiltrados);
            actualizarContadorCarrito();

            const demoMessage = document.createElement('div');
            demoMessage.className = 'demo-message';
            demoMessage.innerHTML = `
                <div style="background:#fff3cd;border:1px solid #ffeaa7;color:#856404;padding:1rem;border-radius:8px;margin-bottom:2rem;">
                    <strong>🚀 Modo Demostración:</strong> Usando datos locales. Para funcionalidad completa, usa PHP + MySQL.
                </div>`;
            if (productsGrid?.parentNode) {
                productsGrid.parentNode.insertBefore(demoMessage, productsGrid);
            }
        } catch {
            if (productsGrid) productsGrid.innerHTML = '<div class="error">Error al cargar productos</div>';
        }
    } finally {
        if (loading) loading.style.display = 'none';
    }
}

function mostrarProductos(productosArray) {
    const productsGrid = document.getElementById('productsGrid');
    if (!productsGrid) return;

    if (productosArray.length === 0) {
        productsGrid.innerHTML = '<div class="no-products">No se encontraron productos</div>';
        return;
    }

    productsGrid.innerHTML = productosArray.map(producto => `
        <div class="product-card" data-categoria="${producto.Nombre_Categoria}">
            <div class="product-image">
                <img src="${producto.imagen_url}" 
                     alt="${producto.Nombre_Producto}" 
                     onerror="this.src='https://via.placeholder.com/300x200?text=Producto'">
                ${producto.etiqueta_especial ? `<div class="product-badge">${producto.etiqueta_especial}</div>` : ''}
            </div>
            <div class="product-info">
                <div class="product-category">${producto.Nombre_Categoria}</div>
                <h3 class="product-name">${producto.Nombre_Producto}</h3>
                <p class="product-description">${producto.Descripcion}</p>
                <div class="product-price">
                    <span class="current-price">$${formatearPrecio(producto.precio_actual)}</span>
                    ${producto.precio_anterior ? `<span class="old-price">$${formatearPrecio(producto.precio_anterior)}</span>` : ''}
                    ${producto.descuento_texto ? `<span class="discount">${producto.descuento_texto}</span>` : ''}
                </div>
                <div class="product-stock">Stock: ${producto.Stock}</div>
                <button onclick="agregarAlCarrito(${producto.Id_Producto}, '${producto.Nombre_Producto.replace(/'/g, "\\'")}')" 
                        class="btn-primary add-to-cart" 
                        ${producto.Stock <= 0 ? 'disabled' : ''}>
                    ${producto.Stock <= 0 ? 'Sin Stock' : 'Agregar al Carrito'}
                </button>
            </div>
        </div>
    `).join('');
}

function formatearPrecio(precio) {
    return parseFloat(precio).toFixed(2);
}

function filtrarPorCategoria(categoria) {
    document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    productosFiltrados = (categoria === 'todas') ? productos : productos.filter(p => p.Nombre_Categoria === categoria);
    mostrarProductos(productosFiltrados);
}

// =====================================================
// 🛒 CARRITO
// =====================================================

async function agregarAlCarrito(idProducto, nombreProducto) {
    if (!usuarioLogueado || !usuarioLogueado.dni) {
        mostrarNotificacion('⚠️ Debes iniciar sesión para agregar productos', 'warning');
        setTimeout(() => { window.location.href = 'login.html'; }, 2000);
        return;
    }

    const producto = productos.find(p => p.Id_Producto === idProducto);
    if (!producto) return mostrarNotificacion('❌ Producto no encontrado', 'error');
    if (producto.Stock <= 0) return mostrarNotificacion('❌ Sin stock', 'error');

    try {
        const response = await fetch('carrito.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({
                accion: 'agregar',
                dni_cliente: usuarioLogueado.dni,
                id_producto: idProducto
            })
        });

        const result = await response.json();
        if (!result.ok) throw new Error(result.error || 'Error al agregar al carrito');

        actualizarCarritoLocal(idProducto, nombreProducto, producto);
        mostrarNotificacion(`✅ ${nombreProducto} agregado al carrito`, 'success');
    } catch (error) {
        console.warn('Servidor no disponible, usando modo local:', error);
        actualizarCarritoLocal(idProducto, nombreProducto, producto);
        mostrarNotificacion(`✅ ${nombreProducto} agregado al carrito (modo local)`, 'success');
    }
}

function actualizarCarritoLocal(idProducto, nombreProducto, producto) {
    const itemExistente = carrito.find(item => item.Id_Producto === idProducto);

    if (itemExistente) {
        if (itemExistente.Cantidad >= producto.Stock) {
            mostrarNotificacion('❌ Stock insuficiente', 'error');
            return;
        }
        itemExistente.Cantidad++;
    } else {
        carrito.push({
            Id_Producto: idProducto,
            Nombre_Producto: nombreProducto,
            Precio_Unitario_Momento: producto.precio_actual,
            Cantidad: 1,
            imagen_url: producto.imagen_url,
            Stock: producto.Stock
        });
    }

    localStorage.setItem('carrito', JSON.stringify(carrito));
    actualizarContadorCarrito();
}

function actualizarContadorCarrito() {
    const cartCount = document.getElementById('cartCount');
    if (!cartCount) return;
    const totalItems = carrito.reduce((t, i) => t + i.Cantidad, 0);
    cartCount.textContent = totalItems;
}

async function cargarCarrito() {
    const loading = document.getElementById('loading');
    const cartContent = document.getElementById('cartContent');
    const emptyCart = document.getElementById('emptyCart');

    if (!usuarioLogueado) {
        if (loading) loading.style.display = 'none';
        if (emptyCart) {
            emptyCart.style.display = 'block';
            emptyCart.innerHTML = `
                <div class="empty-cart-message">
                    <h3>Debes iniciar sesión</h3>
                    <p>Para ver tu carrito necesitas estar logueado</p>
                    <a href="login.html" class="btn-primary">Iniciar Sesión</a>
                </div>`;
        }
        return;
    }

    try {
        const response = await fetch('carrito.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accion: 'obtener', dni_cliente: usuarioLogueado.dni })
        });
        const result = await response.json();

        if (loading) loading.style.display = 'none';

        if (result.ok && result.html?.trim()) {
            if (cartContent) cartContent.style.display = 'block';
            if (emptyCart) emptyCart.style.display = 'none';
            document.getElementById('cartItems').innerHTML = result.html;
            carrito = result.items || [];
            localStorage.setItem('carrito', JSON.stringify(carrito));
            actualizarContadorCarrito();
        } else {
            throw new Error(result.error || 'Carrito vacío');
        }
    } catch (error) {
        console.error('Error al cargar carrito:', error);
        if (loading) loading.style.display = 'none';
        if (carrito.length > 0) {
            if (cartContent) cartContent.style.display = 'block';
            if (emptyCart) emptyCart.style.display = 'none';
            mostrarItemsCarritoLocal(carrito);
        } else {
            if (emptyCart) emptyCart.style.display = 'block';
            if (cartContent) cartContent.style.display = 'none';
        }
        mostrarNotificacion('⚠️ Usando carrito local (modo demo)', 'warning');
    }
}

function mostrarItemsCarritoLocal(items) {
    const cartItems = document.getElementById('cartItems');
    if (!cartItems) return;
    cartItems.innerHTML = '';

    items.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'cart-item';
        div.innerHTML = `
            <div class="item-image"><img src="${item.imagen_url}" alt="${item.Nombre_Producto}" onerror="this.src='https://via.placeholder.com/100x100'"></div>
            <div class="item-details"><h4>${item.Nombre_Producto}</h4><p class="item-price">$${parseFloat(item.Precio_Unitario_Momento).toFixed(2)}</p></div>
            <div class="item-quantity">
                <button onclick="cambiarCantidadLocal(${index}, -1)" class="btn-quantity">-</button>
                <span>Cantidad: ${item.Cantidad}</span>
                <button onclick="cambiarCantidadLocal(${index}, 1)" class="btn-quantity">+</button>
            </div>
            <div class="item-total">
                <span class="subtotal">$${(item.Cantidad * item.Precio_Unitario_Momento).toFixed(2)}</span>
                <button onclick="eliminarDelCarritoLocal(${index})" class="btn-remove">🗑️</button>
            </div>`;
        cartItems.appendChild(div);
    });

    const total = items.reduce((s, i) => s + i.Cantidad * i.Precio_Unitario_Momento, 0);
    actualizarTotales(total);
}

function cambiarCantidadLocal(index, cambio) {
    if (index < 0 || index >= carrito.length) return;
    const item = carrito[index];
    const nueva = item.Cantidad + cambio;
    if (nueva <= 0) return eliminarDelCarritoLocal(index);
    if (nueva > item.Stock) return mostrarNotificacion('❌ Stock insuficiente', 'error');
    item.Cantidad = nueva;
    localStorage.setItem('carrito', JSON.stringify(carrito));
    mostrarItemsCarritoLocal(carrito);
    actualizarContadorCarrito();
}

function eliminarDelCarritoLocal(index) {
    carrito.splice(index, 1);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    if (carrito.length === 0) {
        document.getElementById('cartContent').style.display = 'none';
        document.getElementById('emptyCart').style.display = 'block';
    } else {
        mostrarItemsCarritoLocal(carrito);
    }
    actualizarContadorCarrito();
}

function actualizarTotales(total) {
    document.getElementById('subtotal').textContent = `$${total.toFixed(2)}`;
    document.getElementById('total').textContent = `$${total.toFixed(2)}`;
}

function finalizarCompra() {
    if (carrito.length === 0) return mostrarNotificacion('❌ El carrito está vacío', 'error');
    const total = carrito.reduce((s, i) => s + i.Cantidad * i.Precio_Unitario_Momento, 0);
    const idVenta = Date.now();
    const checkoutBtn = document.getElementById('checkoutBtn');
    if (checkoutBtn) {
        checkoutBtn.disabled = true;
        checkoutBtn.textContent = 'Procesando...';
    }
    setTimeout(() => {
        carrito = [];
        localStorage.setItem('carrito', JSON.stringify(carrito));
        alert(`¡Compra finalizada!\nTotal: $${total.toFixed(2)}\nID: ${idVenta}`);
        window.location.href = 'index.html';
    }, 2000);
}

// =====================================================
// 👤 LOGIN Y REGISTRO DEMO
// =====================================================

function loginDemo(email, password) {
    const usuariosDemo = [
        { id: 1, dni: '12345678', nombre: 'Usuario Demo', email: 'demo@test.com', password: 'demo123' },
        { id: 2, dni: '87654321', nombre: 'María García', email: 'maria@test.com', password: '123456' }
    ];
    const usuario = usuariosDemo.find(u => u.email === email && u.password === password);
    if (usuario) {
        const usuarioLog = {
            id_usuario: usuario.id,
            dni: usuario.dni,
            nombre: usuario.nombre,
            email: usuario.email
        };
        localStorage.setItem('usuario', JSON.stringify(usuarioLog));
        sessionStorage.setItem('usuario', JSON.stringify(usuarioLog));
        usuarioLogueado = usuarioLog;
        return { success: true, data: usuarioLog };
    } else {
        return { success: false, message: 'Credenciales incorrectas' };
    }
}

function registroDemo(dni, nombre, email, password) {
    const nuevoUsuario = { id_usuario: Date.now(), dni, nombre, email };
    localStorage.setItem('usuario', JSON.stringify(nuevoUsuario));
    sessionStorage.setItem('usuario', JSON.stringify(nuevoUsuario));
    usuarioLogueado = nuevoUsuario;
    return { success: true, message: 'Usuario registrado correctamente' };
}

// =====================================================
// 🔔 NOTIFICACIONES
// =====================================================

function mostrarNotificacion(mensaje, tipo = 'info') {
    const n = document.createElement('div');
    n.className = `notification notification-${tipo}`;
    n.textContent = mensaje;
    n.style.cssText = `
        position:fixed;top:20px;right:20px;padding:1rem 1.5rem;border-radius:8px;
        color:white;font-weight:500;z-index:1000;max-width:300px;animation:slideIn .3s ease-out;
    `;
    n.style.background = tipo === 'success' ? '#27ae60' :
                         tipo === 'error' ? '#e74c3c' :
                         tipo === 'warning' ? '#f39c12' : '#3498db';
    document.body.appendChild(n);
    setTimeout(() => {
        n.style.animation = 'slideOut .3s ease-out';
        setTimeout(() => n.remove(), 300);
    }, 4000);
}

// =====================================================
// 🌎 EXPORTAR FUNCIONES GLOBALES
// =====================================================
window.agregarAlCarrito = agregarAlCarrito;
window.filtrarPorCategoria = filtrarPorCategoria;
window.logout = logout;
window.verificarSesion = verificarSesion;
window.finalizarCompra = finalizarCompra;
window.cambiarCantidadLocal = cambiarCantidadLocal;
window.eliminarDelCarritoLocal = eliminarDelCarritoLocal;
window.loginDemo = loginDemo;
window.registroDemo = registroDemo;
