<?php
/**
 * API para finalizar la compra y generar la venta
 * Adaptado para la estructura de BD existente
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    enviarRespuesta(false, 'Método no permitido');
}

try {
    iniciarSesion();
    
    // Verificar si el usuario está logueado
    if (!usuarioLogueado()) {
        enviarRespuesta(false, 'Debe iniciar sesión para finalizar la compra');
    }
    
    $id_usuario = obtenerIdUsuario();
    $dni_usuario = obtenerDNIUsuario();
    
    // Iniciar transacción
    $pdo->beginTransaction();
    
    // Obtener carrito pendiente del usuario
    $stmt = $pdo->prepare("
        SELECT Id_Carrito 
        FROM carrito 
        WHERE DNI_Cliente = ? AND Estado = 'Pendiente'
    ");
    $stmt->execute([intval($dni_usuario)]);
    $carrito = $stmt->fetch();
    
    if (!$carrito) {
        $pdo->rollBack();
        enviarRespuesta(false, 'No hay carrito pendiente para finalizar');
    }
    
    $id_carrito = $carrito['Id_Carrito'];
    
    // Obtener items del carrito con validación de stock
    $stmt = $pdo->prepare("
        SELECT 
            dc.Id_Producto,
            dc.Cantidad,
            dc.Precio_Unitario_Momento,
            p.Stock,
            p.Nombre_Producto,
            (dc.Cantidad * dc.Precio_Unitario_Momento) as Subtotal
        FROM detalle_carrito dc
        INNER JOIN producto p ON dc.Id_Producto = p.Id_Producto
        WHERE dc.Id_Carrito = ?
    ");
    $stmt->execute([$id_carrito]);
    $items = $stmt->fetchAll();
    
    if (empty($items)) {
        $pdo->rollBack();
        enviarRespuesta(false, 'El carrito está vacío');
    }
    
    // Validar stock para todos los productos
    $total = 0;
    foreach ($items as $item) {
        if ($item['Cantidad'] > $item['Stock']) {
            $pdo->rollBack();
            enviarRespuesta(false, "Stock insuficiente para {$item['Nombre_Producto']}. Stock disponible: {$item['Stock']}");
        }
        $total += $item['Subtotal'];
    }
    
    // Crear la venta
    $stmt = $pdo->prepare("
        INSERT INTO venta (id_cliente, Total_Venta) 
        VALUES (?, ?)
    ");
    $stmt->execute([$id_usuario, $total]);
    $id_venta = $pdo->lastInsertId();
    
    // Crear detalles de venta y actualizar stock
    foreach ($items as $item) {
        // Insertar detalle de venta
        $stmt = $pdo->prepare("
            INSERT INTO detalle_venta (Id_Venta, Id_Producto, Cantidad, Precio_Unitario_Venta) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $id_venta, 
            $item['Id_Producto'], 
            $item['Cantidad'], 
            $item['Precio_Unitario_Momento']
        ]);
        
        // Actualizar stock del producto
        $stmt = $pdo->prepare("
            UPDATE producto 
            SET Stock = Stock - ? 
            WHERE Id_Producto = ?
        ");
        $stmt->execute([$item['Cantidad'], $item['Id_Producto']]);
    }
    
    // Marcar carrito como completado
    $stmt = $pdo->prepare("
        UPDATE carrito 
        SET Estado = 'Completado', Total_Final = ?
        WHERE Id_Carrito = ?
    ");
    $stmt->execute([$total, $id_carrito]);
    
    // Confirmar transacción
    $pdo->commit();
    
    enviarRespuesta(true, 'Compra finalizada correctamente', [
        'id_venta' => $id_venta,
        'total' => $total,
        'items_comprados' => count($items)
    ]);
    
} catch(PDOException $e) {
    $pdo->rollBack();
    enviarRespuesta(false, 'Error al finalizar compra: ' . $e->getMessage());
}
?>