<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

include 'conexion.php';

// Verificar si la conexión fue exitosa
if (!isset($pdo)) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: No se pudo establecer conexión con la base de datos'
    ]);
    exit;
}

try {
    // Consulta para obtener todos los productos
    $sql = "SELECT p.Id_Producto, p.Nombre_Producto, p.Descripcion, p.Stock, 
            p.precio_actual, p.precio_anterior, p.imagen_url, p.etiqueta_especial, 
            p.descuento_texto, c.Nombre_Categoria 
            FROM producto p 
            INNER JOIN categoria c ON p.Id_Categoria = c.Id_Categoria";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear los productos para la respuesta
    foreach ($productos as &$producto) {
        // Si no hay imagen_url, usar una imagen por defecto
        if (empty($producto['imagen_url'])) {
            $producto['imagen_url'] = 'https://via.placeholder.com/300x200?text=Producto';
        }
    }
    
    // Devolver respuesta exitosa
    echo json_encode([
        'success' => true,
        'data' => $productos
    ]);
    
} catch (PDOException $e) {
    // En caso de error, devolver respuesta de error
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener los productos: ' . $e->getMessage()
    ]);
}

$pdo = null;
?>