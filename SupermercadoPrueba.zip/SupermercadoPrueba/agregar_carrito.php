<?php
/**
 * API para agregar productos al carrito
 * Adaptado para la estructura de BD existente
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    enviarRespuesta(false, 'Método no permitido');
}

try {
    iniciarSesion();
    
    // Verificar si el usuario está logueado
    if (!usuarioLogueado()) {
        enviarRespuesta(false, 'Debe iniciar sesión para agregar productos al carrito');
    }
    
    $id_usuario = obtenerIdUsuario();
    $dni_usuario = obtenerDNIUsuario();
    
    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    $id_producto = intval($input['id_producto'] ?? 0);
    $cantidad = intval($input['cantidad'] ?? 1);
    
    // Validaciones
    if ($id_producto <= 0) {
        enviarRespuesta(false, 'ID de producto inválido');
    }
    
    if ($cantidad <= 0) {
        enviarRespuesta(false, 'La cantidad debe ser mayor a 0');
    }
    
    // Verificar que el producto existe y tiene stock
    $stmt = $pdo->prepare("
        SELECT Id_Producto, Nombre_Producto, precio_actual, Stock 
        FROM producto 
        WHERE Id_Producto = ? AND Stock >= ?
    ");
    $stmt->execute([$id_producto, $cantidad]);
    $producto = $stmt->fetch();
    
    if (!$producto) {
        enviarRespuesta(false, 'Producto no disponible o stock insuficiente');
    }
    
    // Buscar carrito pendiente del usuario (usando DNI_Cliente como int)
    $stmt = $pdo->prepare("
        SELECT Id_Carrito 
        FROM carrito 
        WHERE DNI_Cliente = ? AND Estado = 'Pendiente'
    ");
    $stmt->execute([intval($dni_usuario)]);
    $carrito = $stmt->fetch();
    
    $id_carrito = null;
    
    if ($carrito) {
        // Usar carrito existente
        $id_carrito = $carrito['Id_Carrito'];
    } else {
        // Crear nuevo carrito (necesita dirección, usamos 1 por defecto)
        $stmt = $pdo->prepare("
            INSERT INTO carrito (DNI_Cliente, Id_Direccion, Estado) 
            VALUES (?, 1, 'Pendiente')
        ");
        $stmt->execute([intval($dni_usuario)]);
        $id_carrito = $pdo->lastInsertId();
    }
    
    // Verificar si el producto ya está en el carrito
    $stmt = $pdo->prepare("
        SELECT Id_Detalle_Carrito, Cantidad 
        FROM detalle_carrito 
        WHERE Id_Carrito = ? AND Id_Producto = ?
    ");
    $stmt->execute([$id_carrito, $id_producto]);
    $detalle_existente = $stmt->fetch();
    
    if ($detalle_existente) {
        // Actualizar cantidad existente
        $nueva_cantidad = $detalle_existente['Cantidad'] + $cantidad;
        
        // Verificar stock para la nueva cantidad
        if ($nueva_cantidad > $producto['Stock']) {
            enviarRespuesta(false, 'Stock insuficiente. Stock disponible: ' . $producto['Stock']);
        }
        
        $stmt = $pdo->prepare("
            UPDATE detalle_carrito 
            SET Cantidad = ? 
            WHERE Id_Detalle_Carrito = ?
        ");
        $stmt->execute([$nueva_cantidad, $detalle_existente['Id_Detalle_Carrito']]);
        
    } else {
        // Agregar nuevo producto al carrito
        $stmt = $pdo->prepare("
            INSERT INTO detalle_carrito (Id_Carrito, Id_Producto, Cantidad, Precio_Unitario_Momento) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$id_carrito, $id_producto, $cantidad, $producto['precio_actual']]);
    }
    
    enviarRespuesta(true, 'Producto agregado al carrito correctamente');
    
} catch(PDOException $e) {
    enviarRespuesta(false, 'Error al agregar producto al carrito: ' . $e->getMessage());
}
?>