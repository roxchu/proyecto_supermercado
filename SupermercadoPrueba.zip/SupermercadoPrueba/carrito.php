<?php
// =======================================
// carrito.php - Manejo del carrito de compras
// =======================================

header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_start();

// =======================================
// CONEXIÓN A LA BASE DE DATOS
// =======================================
require 'conexion.php';

// =======================================
// FUNCIÓN AUXILIAR: Responder en JSON
// =======================================
function responder($ok, $data = [])
{
    echo json_encode(array_merge(['ok' => $ok], $data), JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // =======================================
    // 1️⃣ LEER DATOS DE ENTRADA
    // =======================================
    $input = file_get_contents('php://input');
    if (!empty($input)) {
        $_POST = json_decode($input, true) ?? [];
    }

    $accion = $_POST['accion'] ?? '';
    $dni_cliente = $_POST['dni_cliente'] ?? null;
    $id_producto = $_POST['id_producto'] ?? null;

    if (!$dni_cliente) {
        throw new Exception('Falta DNI del cliente');
    }

    // =======================================
    // 2️⃣ BUSCAR O CREAR CARRITO PENDIENTE
    // =======================================
    $stmt = $pdo->prepare("SELECT * FROM carrito WHERE DNI_Cliente = ? AND Estado = 'Pendiente'");
    $stmt->execute([$dni_cliente]);
    $carrito = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$carrito) {
        $stmt = $pdo->prepare("INSERT INTO carrito (DNI_Cliente, Id_Direccion, Estado) VALUES (?, 0, 'Pendiente')");
        $stmt->execute([$dni_cliente]);
        $id_carrito = $pdo->lastInsertId();
    } else {
        $id_carrito = $carrito['Id_Carrito'];
    }

    // =======================================
    // 3️⃣ MANEJAR ACCIONES
    // =======================================
    if ($accion === 'agregar' && $id_producto) {
        // Obtener precio actual
        $stmt = $pdo->prepare("SELECT precio_actual FROM producto WHERE Id_Producto = ?");
        $stmt->execute([$id_producto]);
        $producto = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$producto) {
            throw new Exception("Producto no encontrado");
        }

        // Verificar si ya está en el carrito
        $stmt = $pdo->prepare("SELECT * FROM detalle_carrito WHERE Id_Carrito = ? AND Id_Producto = ?");
        $stmt->execute([$id_carrito, $id_producto]);
        $detalle = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($detalle) {
            // Aumentar cantidad
            $stmt = $pdo->prepare("UPDATE detalle_carrito SET Cantidad = Cantidad + 1 WHERE Id_Detalle_Carrito = ?");
            $stmt->execute([$detalle['Id_Detalle_Carrito']]);
        } else {
            // Insertar nuevo producto
            $stmt = $pdo->prepare("INSERT INTO detalle_carrito (Id_Carrito, Id_Producto, Cantidad, Precio_Unitario_Momento)
                                   VALUES (?, ?, 1, ?)");
            $stmt->execute([$id_carrito, $id_producto, $producto['precio_actual']]);
        }
    }

    // =======================================
    // 4️⃣ ACTUALIZAR CANTIDAD
    // =======================================
    if ($accion === 'cambiar_cantidad' && $id_producto) {
        $delta = (int)($_POST['delta'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM detalle_carrito WHERE Id_Carrito = ? AND Id_Producto = ?");
        $stmt->execute([$id_carrito, $id_producto]);
        $detalle = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($detalle) {
            $nuevaCantidad = $detalle['Cantidad'] + $delta;
            if ($nuevaCantidad <= 0) {
                $stmt = $pdo->prepare("DELETE FROM detalle_carrito WHERE Id_Detalle_Carrito = ?");
                $stmt->execute([$detalle['Id_Detalle_Carrito']]);
            } else {
                $stmt = $pdo->prepare("UPDATE detalle_carrito SET Cantidad = ? WHERE Id_Detalle_Carrito = ?");
                $stmt->execute([$nuevaCantidad, $detalle['Id_Detalle_Carrito']]);
            }
        }
    }

    // =======================================
    // 5️⃣ ELIMINAR PRODUCTO DEL CARRITO
    // =======================================
    if ($accion === 'eliminar' && $id_producto) {
        $stmt = $pdo->prepare("DELETE FROM detalle_carrito WHERE Id_Carrito = ? AND Id_Producto = ?");
        $stmt->execute([$id_carrito, $id_producto]);
    }

    // =======================================
    // 6️⃣ OBTENER CARRITO ACTUALIZADO
    // =======================================
    $stmt = $pdo->prepare("
        SELECT p.Id_Producto, p.Nombre_Producto, p.imagen_url, 
               d.Cantidad, d.Precio_Unitario_Momento,
               (d.Cantidad * d.Precio_Unitario_Momento) AS Subtotal
        FROM detalle_carrito d
        JOIN producto p ON d.Id_Producto = p.Id_Producto
        WHERE d.Id_Carrito = ?
    ");
    $stmt->execute([$id_carrito]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // =======================================
    // 7️⃣ GENERAR HTML DEL CARRITO
    // =======================================
    $total = 0;
    $itemsHtml = '';

    foreach ($items as $item) {
        $total += $item['Subtotal'];
        $itemsHtml .= "
        <div class='cart-item'>
            <div class='item-image'>
                <img src='{$item['imagen_url']}' alt='{$item['Nombre_Producto']}' 
                     onerror=\"this.src='https://via.placeholder.com/100x100'\" />
            </div>
            <div class='item-details'>
                <h4>{$item['Nombre_Producto']}</h4>
                <p class='item-price'>$" . number_format($item['Precio_Unitario_Momento'], 2) . "</p>
            </div>
            <div class='item-quantity'>
                <button onclick='cambiarCantidad({$item['Id_Producto']}, -1)' class='btn-quantity'>-</button>
                <span>Cantidad: {$item['Cantidad']}</span>
                <button onclick='cambiarCantidad({$item['Id_Producto']}, 1)' class='btn-quantity'>+</button>
            </div>
            <div class='item-total'>
                <span class='subtotal'>$" . number_format($item['Subtotal'], 2) . "</span>
                <button onclick='eliminarDelCarrito({$item['Id_Producto']})' class='btn-remove'>🗑️</button>
            </div>
        </div>";
    }

    // =======================================
    // 8️⃣ RESPUESTA FINAL
    // =======================================
    responder(true, [
        'html' => $itemsHtml,
        'total' => $total,
        'itemCount' => count($items)
    ]);

} catch (Exception $e) {
    http_response_code(400);
    responder(false, ['error' => $e->getMessage()]);
}
?>
