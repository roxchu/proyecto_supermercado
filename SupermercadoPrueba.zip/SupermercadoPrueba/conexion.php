<?php
/**
 * Archivo de conexión a la base de datos MySQL usando PDO
 * Configuración para XAMPP/localhost
 * Adaptado para la estructura de BD existente
 */

// Configuración de la base de datos
$host = 'localhost';
$dbname = 'supermercado';
$username = 'root';
$password = '';

try {
    // Crear conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Configurar PDO para mostrar errores
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    // En caso de error de conexión
    die(json_encode([
        'success' => false,
        'message' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]));
}

/**
 * Función para iniciar sesión si no está iniciada
 */
function iniciarSesion() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

/**
 * Función para verificar si el usuario está logueado
 */
function usuarioLogueado() {
    iniciarSesion();
    return isset($_SESSION['id_usuario']);
}

/**
 * Función para obtener el ID del usuario logueado
 */
function obtenerIdUsuario() {
    iniciarSesion();
    return $_SESSION['id_usuario'] ?? null;
}

/**
 * Función para obtener el DNI del usuario logueado
 */
function obtenerDNIUsuario() {
    iniciarSesion();
    return $_SESSION['dni_usuario'] ?? null;
}

/**
 * Función para enviar respuesta JSON
 */
function enviarRespuesta($success, $message, $data = null) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}
?>