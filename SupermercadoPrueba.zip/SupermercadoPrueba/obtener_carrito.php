<?php
// =======================================
// obtener_carrito.php - Devuelve los productos del carrito actual
// =======================================

header('Content-Type: application/json; charset=utf-8');
session_start();
require 'conexion.php';

try {
    // Obtener DNI del cliente desde la sesión o desde la solicitud
    $dni_cliente = $_SESSION['dni_cliente'] ?? ($_GET['dni_cliente'] ?? null);

    if (!$dni_cliente) {
        echo json_encode([
            'success' => false,
            'message' => 'Debe iniciar sesión para ver el carrito',
            'data' => []
        ]);
        exit;
    }

    // Obtener carrito pendiente
    $stmt = $pdo->prepare("
        SELECT c.Id_Carrito
        FROM carrito c
        WHERE c.DNI_Cliente = ? AND c.Estado = 'Pendiente'
        LIMIT 1
    ");
    $stmt->execute([$dni_cliente]);
    $carrito = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$carrito) {
        echo json_encode([
            'success' => true,
            'data' => [
                'items' => [],
                'total' => 0
            ]
        ]);
        exit;
    }

    // Obtener detalles del carrito
    $stmt = $pdo->prepare("
        SELECT 
            dc.Id_Producto,
            dc.Cantidad,
            dc.Precio_Unitario_Momento,
            p.Nombre_Producto,
            p.imagen_url,
            (dc.Cantidad * dc.Precio_Unitario_Momento) AS Subtotal
        FROM detalle_carrito dc
        INNER JOIN producto p ON dc.Id_Producto = p.Id_Producto
        WHERE dc.Id_Carrito = ?
    ");
    $stmt->execute([$carrito['Id_Carrito']]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calcular total
    $total = 0;
    foreach ($items as $item) {
        $total += $item['Subtotal'];
    }

    echo json_encode([
        'success' => true,
        'message' => 'Carrito obtenido correctamente',
        'data' => [
            'items' => $items,
            'total' => $total
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener carrito: ' . $e->getMessage()
    ]);
}
?>
