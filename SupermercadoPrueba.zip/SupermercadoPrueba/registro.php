<?php
/**
 * API para registro de nuevos usuarios
 * Adaptado para la estructura de BD existente
 */

require_once 'conexion.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    enviarRespuesta(false, 'Método no permitido');
}

try {
    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    $dni = trim($input['dni'] ?? '');
    $nombre = trim($input['nombre'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    
    // Validaciones básicas
    if (empty($dni) || empty($nombre) || empty($email) || empty($password)) {
        enviarRespuesta(false, 'Todos los campos son obligatorios');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        enviarRespuesta(false, 'El email no es válido');
    }
    
    if (strlen($password) < 6) {
        enviarRespuesta(false, 'La contraseña debe tener al menos 6 caracteres');
    }
    
    // Verificar si el DNI o email ya existen
    $stmt = $pdo->prepare("SELECT id_usuario FROM usuario WHERE DNI = ? OR correo = ?");
    $stmt->execute([$dni, $email]);
    
    if ($stmt->fetch()) {
        enviarRespuesta(false, 'El DNI o email ya están registrados');
    }
    
    // Encriptar contraseña
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
    // Iniciar transacción
    $pdo->beginTransaction();
    
    // Insertar nuevo usuario (rol 3 = cliente)
    $stmt = $pdo->prepare("
        INSERT INTO usuario (DNI, id_rol, nombre_usuario, correo, contrasena) 
        VALUES (?, 3, ?, ?, ?)
    ");
    
    $stmt->execute([$dni, $nombre, $email, $passwordHash]);
    $id_usuario = $pdo->lastInsertId();
    
    // Insertar en tabla cliente
    $stmt = $pdo->prepare("INSERT INTO cliente (id_cliente) VALUES (?)");
    $stmt->execute([$id_usuario]);
    
    // Confirmar transacción
    $pdo->commit();
    
    enviarRespuesta(true, 'Usuario registrado correctamente');
    
} catch(PDOException $e) {
    $pdo->rollBack();
    if ($e->getCode() == 23000) { // Duplicate entry
        enviarRespuesta(false, 'El DNI o email ya están registrados');
    } else {
        enviarRespuesta(false, 'Error al registrar usuario: ' . $e->getMessage());
    }
}
?>